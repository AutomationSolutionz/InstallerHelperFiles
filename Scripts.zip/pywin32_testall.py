#!c:\python27\python.exe
# EASY-INSTALL-SCRIPT: 'pywin32==221',u'pywin32_testall.py'
__requires__ = 'pywin32==221'
__import__('pkg_resources').run_script('pywin32==221', u'pywin32_testall.py')
